# Introduction
This is a sample api recipe. it will be replaced by the js content.
